package com.example.aluno.myapplication;

public class PessoaSalvaMeta {

    private String usuarioLogado;
    private String usuarioCriador;
    private String descrMeta;
    private int id;

    public PessoaSalvaMeta() {
    }

    public PessoaSalvaMeta(String usuarioLogado, String usuarioCriador, String descrMeta) {

        this.usuarioLogado = usuarioLogado;
        this.usuarioCriador = usuarioCriador;
        this.descrMeta = descrMeta;
    }

    public String getUsuarioLogado() {
        return usuarioLogado;
    }

    public void setUsuarioLogado(String usuarioLogado) {
        this.usuarioLogado = usuarioLogado;
    }

    public String getUsuarioCriador() {
        return usuarioCriador;
    }

    public void setUsuarioCriador(String usuarioCriador) {
        this.usuarioCriador = usuarioCriador;
    }

    public String getDescrMeta() {
        return descrMeta;
    }

    public void setDescrMeta(String descrMeta) {
        this.descrMeta = descrMeta;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
