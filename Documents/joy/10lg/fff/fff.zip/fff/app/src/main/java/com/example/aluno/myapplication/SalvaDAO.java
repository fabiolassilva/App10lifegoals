package com.example.aluno.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class SalvaDAO {
    private static SQLiteDatabase bd;
    private static CriaBanco openHelper;

    public SalvaDAO(Context contexto){
        openHelper = new CriaBanco(contexto);
    }

    static void abrir(){
        bd = openHelper.getWritableDatabase();
    }

    private static void fechar (){
        bd.close();
    }

    public PessoaSalvaMeta salvar(String usuarioLogado, String usuarioCriador, String descrMeta){
        ContentValues valores = new ContentValues();
        valores.put("usuarioLogado",usuarioLogado );
        valores.put("usuarioCriador", usuarioCriador);
        valores.put("descrMeta",descrMeta);

        bd.insert("pessoasalvameta", null, valores);
        PessoaSalvaMeta psm = new PessoaSalvaMeta();
        psm.setUsuarioLogado(usuarioLogado);
        psm.setUsuarioCriador(usuarioCriador);
        psm.setDescrMeta(descrMeta);

        return psm;
    }

    public ArrayList<PessoaSalvaMeta> metasSalvas(String usuario){
        ArrayList<PessoaSalvaMeta> metasalvas = new ArrayList<PessoaSalvaMeta>();
        String[] campos =  {"usuarioCriador", "descrMeta"};
        String where = "usuarioLogado" + "= '" + usuario +"'";
        abrir();
        Cursor cursor = bd.rawQuery("Select descrMeta, usuarioCriador from pessoasalvameta where usuarioLogado=?" , new String[]{""+usuario});
        while(cursor.moveToNext()){
            PessoaSalvaMeta m = new PessoaSalvaMeta();
            m.setUsuarioCriador(cursor.getString(cursor.getColumnIndex("usuarioCriador")));
            m.setDescrMeta(cursor.getString(cursor.getColumnIndex("descrMeta")));
            metasalvas.add(m);
        }

        cursor.close();
        fechar();
        return metasalvas;
    }
}
